<!DOCTYPE html>
<html>
<head>
	<title>Portfolio</title>
	<script type="text/javascript" href = "js.js"></script>
</head>

<style type="text/css">

	#headerDiv{
		position: fixed;
		top: 0px;
		left: 0px;
		width: 100%;
		height: 70px;
		background-color: rgba(0,0,0,0.7);
		display: block;
		transition: top 0.3s;
		z-index: 100;
	}	
	
	#headerLeft{
		/*code for logo portion*/
	}
	#headerRight{
		position: absolute;
		top: 20px;
		right: 0px;
		width: 50%;
		height: 50px;
		text-align: right;
		background-color: transparent;
		color: #fff;
		font-family: "Lucida Console", Courier, monospace;
		font-weight: bold;
		font-size: 15px;
		letter-spacing: 1px;

	}
	.headerSpan{
		margin-top: 10px;
		margin-right: 10px;
		padding: 10px 10px;
		padding-bottom: 30px;
		display: inline-block;
	}
	.headerSpan:hover{
		color: #ff704d;
	}
	.headerSpan::after{
		content: '';
	    display: block;
	    margin-top: 10px;
	    width: 0;
	    height: 2px;
	    background: #ff704d;
	    transition: width .3s;
	}
	.headerSpan:hover::after {
		width: 100%;
	}
	#centerDiv{
		position: absolute;
		top: 0px;
		left: 0px;
		width: 100%;
		height: 2600px;
		background-color: transparent;
	}
	#centerHome{
		position: absolute;
		top: 0px;
		left: 0px;
		width: 100%;
		height: 1600px;
		background-image: url('img1.jpg');
		background-attachment: fixed;
	    background-position: center;
	    background-repeat: no-repeat;
	    background-size: cover;
	}
</style>

<body>

<div id = "headerDiv">
	<div id = "headerLeft"></div>
	<div id = "headerRight">
		<span class = "headerSpan">HOME</span>
		<span class = "headerSpan">ABOUT US</span>
		<span class = "headerSpan">CONTACT US</span>
		<span class = "headerSpan">JOIN NOW!</span>
	</div>
</div>
<div id = "centerDiv">
	
	<div id = "centerHome">
		
	</div>

</div>

</body>
</html>
<script type="text/javascript">

	window.onscroll = function() {myFunction()};

	var header = document.getElementById("headerDiv");
	var sticky = header.offsetTop;

	function myFunction() {
	  if (window.pageYOffset > sticky) {
	    header.css('height', '50px');
	  } else {
	    header.css('height', '70px');
	  }
	}
	

</script>